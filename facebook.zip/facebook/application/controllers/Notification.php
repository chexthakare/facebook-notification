<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notification extends CI_Controller
{
	public function __construct(){
		parent::__construct();
		$this->load->model('notification_model');
	}

	public function index(){
	  $this->load->view('notification');	
	}

	public function insert_put(){
		$this->notification_model->insert_put();
	}

	public function get_notification(){
		$view = $this->input->post('view');
		$data =$this->notification_model->get_notification($view);
		echo json_encode($data);
	}
	
	
}
?>