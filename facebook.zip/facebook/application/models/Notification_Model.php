<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notification_Model extends CI_Model

{
	public function insert_put(){

		$data=array(
		'comment_subject'=>$this->input->post('subject'),
		'comment_text'=>$this->input->post('comment'),
		);

		$this->db->insert('comments',$data);	
	}

	public function get_notification($view)
	{
		if($view != 1)
		 {
		  $this->db->query("UPDATE comments SET comment_status=1 WHERE comment_status=0");
		 }
		 $query = $this->db->query("SELECT * FROM comments ORDER BY comment_id DESC LIMIT 5");
		 $output = '';
		 if($query->num_rows() > 0)
			 {
			foreach ($query->result() as $row)
				{
			        $output .= '
					   <li>
					    <a href="#">
					     <strong>'.$row->comment_subject.'</strong><br />
					     <small><em>'.$row->comment_text.'</em></small>
					    </a>
					   </li>
					   <li class="divider"></li>
					   ';
				}
			 }
			 else
			 {
			  $output .= '<li><a href="#" class="text-bold text-italic">No Notification Found</a></li>';
			 }

			 $result_1 = $this->db->query("SELECT * FROM comments WHERE comment_status=0") ;
			 $count = $result_1->num_rows();
			 $data = array(
			  'notification'   => $output,
			  'unseen_notification' => $count
			 );
			 return $data;
	}	
}

?>